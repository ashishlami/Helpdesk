'use strict';

require('../');

const Promise = require('bluebird');
const expect = require('chai').expect;
const request = require('request-promise');
const cherwellservice = require('../../app/services/cherwell_service');
const constants = require('../../config').apiCherwell;

describe('cherwellService', function() {
    let service, requestStub;

    describe('.getToken',function(){
        beforeEach(function () {
            requestStub = {
                post: function () {
                    return new Promise(function (resolve, reject) {
                        resolve({
                            access_token: 'SomeAlphaNumericCharacters'
                        });
                    });
                }
            };

            service = cherwellservice(constants, requestStub);
        });

        context('shared', function () {
            beforeEach(function () {
                service = cherwellservice(constants, request);
            });

            it('receives a token', function () {
                expect(service.getToken).to.not.be.undefined;
            });
            it('creates an incident', function () {
                expect(service.createIncident).to.not.be.undefined;
            });
        });

        context('success', function () {
            it('returns a token', function () {
                return service.getToken().then(function (message) {
                    expect(message.access_token).to.equal('SomeAlphaNumericCharacters');
                });
            });
        });
    })
});
