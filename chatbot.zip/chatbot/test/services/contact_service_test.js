'use strict';

require('../');

const expect = require('chai').expect;
const Promise = require('bluebird');
const contactService = require('../../app/services/contact_service');
const constants = require('../../config').messages;
const voiceConstants = require('../../config').voiceOnlyData;

describe('contactService', function () {
  let service, moment, moment_tz, facebookService, url, req;

  beforeEach(function () {
    req = {
      body: {
        result: {
          action: 'get.contact',
          resolvedQuery: 'query',
          contexts: [],
          fulfillment: {
            speech: ''
          }
        },
        originalRequest: {
          data: {
            sender: {
              id: null
            }
          }
        }
      }
    };
  });

  describe('.execute', function () {
    beforeEach(function () {
      url = {
        format: function (resolvedQuery) {
          return resolvedQuery;
        },
      };
    });

    context('shared', function () {
      it('should initialize its functions', function () {
        expect(contactService({}, {}, {}, {}).execute).isFunction;
      });

      it('checks office hours using the correct timezone', function () {
        let tz = 'wrong';

        moment_tz = function () {
          return {
            tz: function (timeZone) {
              tz = timeZone;
              return { format: function () { return 10; } }
            }
          }
        };

        moment = function () {
          return { format: function () { return 'Monday'; } }
        };

        service = contactService(Promise, constants, voiceConstants, moment_tz, moment, facebookService, url);
        return service.execute(req).then(function () {
          expect(tz).to.eql('America/Chicago');
        });
      });
    });

    context('when the request comes from a google device', function () {
      beforeEach(function () {
        moment_tz = function () { return { tz: function () { return { format: function () { return 10; } } } } };
        moment = function () { return { format: function () { return 'Monday' } } };
        service = contactService(Promise, constants, voiceConstants, moment_tz, moment, facebookService, url);
      });

      it('should contain the office closed message', function () {
        req.body.result.contexts = [{ name: 'associate', lifespan: 1 }];
        req.body.originalRequest.source = 'google';
        return service.execute(req).then(function (message) {
          expect(message).to.equal('You can connect with us via email, Associate Services at associateservices@legalshield.com.');
        });
      });
    });

    context('during office hours', function () {
      beforeEach(function () {
        moment_tz = function () { return { tz: function () { return { format: function () { return 10; } } } } };
        moment = function () { return { format: function () { return 'Monday' } } };
        service = contactService(Promise, constants, voiceConstants, moment_tz, moment, facebookService, url);
      });

      it('returns the office open message', function () {
        return service.execute(req).then(function (message) {
          expect(message).to.include('I can connect you with a live ');
        });
      });

      context('when the context is associate', function () {
        it('returns the link to Associate Services', function () {
          req.body.result.contexts = [{ name: 'associate', lifespan: 1 }];
          return service.execute(req).then(function (message) {
            expect(message).to.equal('I can connect you with a live Associate Services agent at https://home-c4.incontact.com/inContact/ChatClient/ChatClientPatron.aspx?poc=60ce508d-19e9-4c70-bb47-1e6ee012d06a&bu=4595114&p1=&p2=&p3=Website&p4=query.');
          });
        });
      });

      context('when the context is member', function () {
        it('returns the link to Member Services', function () {
          req.body.result.contexts = [{ name: 'member', lifespan: 1 }];
          return service.execute(req).then(function (message) {
            expect(message).to.equal('I can connect you with a live Member Services agent at https://home-c4.incontact.com/inContact/ChatClient/ChatClientPatron.aspx?poc=785ac45b-4579-4198-9376-359d21b87f27&bu=4595114&p1=&p2=&p3=Website&p4=query.');
          });
        });
      });

      context('when the context is not defined', function () {
        it('returns the links to Member Services and Associate Services', function () {
          return service.execute(req).then(function (message) {
            expect(message).to.equal('I can connect you with a live Member Services agent at https://home-c4.incontact.com/inContact/ChatClient/ChatClientPatron.aspx?poc=785ac45b-4579-4198-9376-359d21b87f27&bu=4595114&p1=&p2=&p3=Website&p4=query. Or Associate Services agent at https://home-c4.incontact.com/inContact/ChatClient/ChatClientPatron.aspx?poc=60ce508d-19e9-4c70-bb47-1e6ee012d06a&bu=4595114&p1=&p2=&p3=Website&p4=query.');
          });
        });
      });

      context('when dataSenderID is defined', function () {
        beforeEach(function () {
          facebookService = {
            facebookGraph: function () { return new Promise(function (resolve, reject) { resolve({ first_name: 'AAAA', last_name: 'BBBB' }); }); }
          };

          service = contactService(Promise, constants, voiceConstants, moment_tz, moment, facebookService, url);
        });

        it('returns the first name and last name from facebook service', function () {
          req.body.originalRequest.data.sender.id = '123';
          return service.execute(req).then(function (message) {
            expect(message).to.include('&p1=&p2=AAAA%20BBBB&p3=Facebook&p4=query');
          });
        });
      });

      context('when dataSenderID is not defined', function () {
        beforeEach(function () {
          facebookService = {
            facebookGraph: function () { return new Promise(function (resolve, reject) { resolve({ first_name: 'AAAA', last_name: 'BBBB' }); }); }
          };

          service = contactService(Promise, constants, voiceConstants, moment_tz, moment, facebookService, url);
        });

        it('does not return the first name and last name from facebook service', function () {
          return service.execute(req).then(function (message) {
            expect(message).to.include('&p1=&p2=&p3=Website&p4=query');
          });
        });
      });
    });

    context('outside of office hours', function () {
      beforeEach(function () {
        moment_tz = function () { return { tz: function () { return { format: function () { return 22; } } } } };
        moment = function () { return { format: function () { return 'Monday' } } };
        service = contactService(Promise, constants, voiceConstants, moment_tz, moment, facebookService, url);
      });

      it('returns the office closed message ', function () {
        return service.execute(req).then(function (message) {
          expect(message).to.include('You can connect with us via email, ');
        });
      });

      context('when the context is member', function () {
        it('returns the email to Member Services', function () {
          req.body.result.contexts = [{ name: 'member', lifespan: 1 }];
          return service.execute(req).then(function (message) {
            expect(message).to.equal('You can connect with us via email, Member Services at memberservices@legalshield.com.');
          });
        });
      });

      context('when the context is associate', function () {
        it('returns the email to Associate Services', function () {
          req.body.result.contexts = [{ name: 'associate', lifespan: 1 }];
          return service.execute(req).then(function (message) {
            expect(message).to.equal('You can connect with us via email, Associate Services at associateservices@legalshield.com.');
          });
        });
      });

      context('when the context is not defined', function () {
        it('returns the email to Member Services and Associate Services', function () {
          return service.execute(req).then(function (message) {
            expect(message).to.equal('You can connect with us via email, Member Services at memberservices@legalshield.com. Or Associate Services at associateservices@legalshield.com.');
          });
        });
      });
    });

    context('outside of office hours on a weekend', function () {
      beforeEach(function () {
        moment_tz = function () { return { tz: function () { return { format: function () { return 10; } } } } };
        moment = function () { return { format: function () { return 'Sunday' } } };
        service = contactService(Promise, constants, voiceConstants, moment_tz, moment, facebookService, url);
      });

      it('returns the office closed message ', function () {
        return service.execute(req).then(function (message) {
          expect(message).to.include('You can connect with us via email, ');
        });
      });
    });
  });
});
