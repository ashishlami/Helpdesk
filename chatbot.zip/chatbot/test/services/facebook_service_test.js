'use strict';

require('../');

const expect = require('chai').expect;
const facebookService = require('../../app/services/facebook_service');

describe('facebookService', function () {
  describe('.facebookGraph', function () {
    let facebook, service, urlformat, request, url;

    beforeEach(function () {
      facebook = {
        domain: 'https://test.com/v2.6/',
        access_token: 'token'
      };

      url = {
        parse: function (domain) {
          return { search: null, pathname: null, href: domain }
        },
        format: function (resourceUrl) {
          urlformat = `${resourceUrl.href}${resourceUrl.pathname}${resourceUrl.search}`;
          return urlformat;
        },
      };

      request = function (json) {
        return new Promise(function (resolve, reject) {
          resolve({ first_name: 'AAAA', last_name: 'BBBB' });
        });
      };

      service = facebookService(request, url, facebook);
    });

    context('shared', function () {
      it('should initialize its functions', function () {
        expect(facebookService({}, {}, {}, {}).facebookGraph).isFunction;
      });

      it('checks if url returns the correct format', function () {
        return service.facebookGraph('123').then(function (responses) {
          expect(urlformat).to.eql('https://test.com/v2.6/123?fields=first_name,last_name&access_token=token');
        });
      });

      it('checks if request returns JSON with the Name and Last Name', function () {
        return service.facebookGraph('123').then(function (responses) {
          expect(responses).to.eql({ first_name: 'AAAA', last_name: 'BBBB' });
        });
      });
    });
  });
});
