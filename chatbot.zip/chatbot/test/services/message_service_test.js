'use strict';

require('../');

const expect = require('chai').expect;
const Promise = require('bluebird');
const messageService = require('../../app/services/message_service');
const constants = require('../../config').messages;

describe('messageService', function () {
  let service, req;

  describe('.execute', function () {
    beforeEach(function () {
      req = {
        body: {
          result: {
            action: '',
            resolvedQuery: '',
            contexts: [],
            fulfillment: {
              speech: ''
            }
          },
          originalRequest: {
            data: {
              sender: {
                id: null
              }
            }
          }
        }
      };
    });

    context('shared', function () {
      it('should initialize its functions', function () {
        expect(messageService({}, {}, {}, {}).execute).isFunction;
      });
    });

    context('when speech is not defined', function () {
      beforeEach(function () {
        service = messageService(Promise, constants);
      });

      it('returns the default, office closed, and member services email messages', function () {
        return service.execute(req).then(function (message) {
          expect(message).to.equal('Sorry, I don\'t know that one, I\'m still learning. Please try rephrasing your question. If you prefer, You can connect with us via email, Member Services at memberservices@legalshield.com.');
        });
      });
    });

    context('when speech is defined', function () {
      beforeEach(function () {
        req.body.result.fulfillment.speech = 'Tacos are a most versatile fruit.';
        service = messageService(Promise, constants);
      });

      it('returns the fulfillment speech in the message without the followup message', function () {
        return service.execute(req).then(function (message) {
          expect(message).to.equal('Tacos are a most versatile fruit.');
        });
      });
    });
  });
});
