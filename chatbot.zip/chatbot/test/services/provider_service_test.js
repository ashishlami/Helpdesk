'use strict';

require('../');

const chai = require("chai");
const expect = require('chai').expect;
const sinon = require('sinon');
const sinonChai = require("sinon-chai");
const Promise = require('bluebird');
const providerService = require('../../app/services/provider_service');

chai.use(sinonChai);

describe('providerService', function () {
  let service, parameter, region, providerRepository, messages, req;

  beforeEach(function () {
    messages = {
      noProviderFound: 'The location you provided seems to be outside of our coverage area. Please ensure the location you provided is correct.'
    };

  });

  describe('.execute', function () {
    beforeEach(function () {
      providerRepository = {
        findOne: function (query) {
          return new Promise(function (resolve, reject) {
            resolve({
              name: 'NameTest',
              phone_numbers: [{ number: '888-888 - 8888', type: 'Toll-Free' }]
            });
          });
        }
      }
      sinon.spy(providerRepository, 'findOne');
      service = providerService(Promise, messages, providerRepository);
    });

    it('returns the provider information according to US zip code', function () {
      req = { body: { result: { parameters: { zip: 12345 } } } };
      return service.execute(req).then(function (message) {
        expect(message).to.eql('Your provider\'s name is: NameTest. Phone number is: 888-888 - 8888.');
      });
    });

    it('removes spaces before sending the input to the repository', function () {
      req = { body: { result: { parameters: { zip: 'T2P 2M5' } } } };
      return service.execute(req).then(function (message) {
        expect(providerRepository.findOne).to.have.been.calledWith({ postal_code: 'T2P2M5' });
      });
    });

    it('removes dashes before sending the input to the repository', function () {
      req = { body: { result: { parameters: { zip: 'T2P-2M5' } } } };
      return service.execute(req).then(function (message) {
        expect(providerRepository.findOne).to.have.been.calledWith({ postal_code: 'T2P2M5' });
      });
    });

    it('resolves state to state abbreviation before sending the input to the repository', function () {
      req = { body: { result: { parameters: { region: 'Oklahoma' } } } };
      return service.execute(req).then(function (message) {
        expect(providerRepository.findOne).to.have.been.calledWith({ region: 'OK' });
      });
    });

    it('sends state abbreviation to the repository if that was the input', function () {
      req = { body: { result: { parameters: { region: 'mb' } } } };
      return service.execute(req).then(function (message) {
        expect(providerRepository.findOne).to.have.been.calledWith({ region: 'MB' });
      });
    });

    it('returns the stock message when the state is not found', function () {
      req = { body: { result: { parameters: { region: 'Minisoda' } } } };
      return service.execute(req).then(function (message) {
        expect(message).to.eql(messages.noProviderFound);
      });
    });
  });
});
