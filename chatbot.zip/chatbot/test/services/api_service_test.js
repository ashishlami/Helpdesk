'use strict';

require('../');

const expect = require('chai').expect;
const sinon = require('sinon');
const URL = require('url');
const Promise = require('bluebird');
const _ = require('lodash');
const apiService = require('../../app/services/api_service');

describe('apiService', function () {
  let config, http, service;

  beforeEach(function () {
    config = {
      client_id: 12345,
      client_secret: 54321,
      host: 'http://api.test.com'
    };

    http = {
      get: function () { return new Promise(function (res) { res([]); }) }
    };
  });

  context('making the correct call', function () {
    let args;

    beforeEach(function () {
      sinon.spy(http, 'get');

      apiService(config, http, URL, _)('get', {});
      args = http.get.getCall(0).args[0];
    });

    it('makes a get request', function () {
      expect(http.get).to.have.been.called;
    });

    it('uses the correct base domain', function () {
      expect(args.url).to.eql('http://api.test.com');
    });

    it('uses the correct headers', function () {
      expect(args.headers).to.eql({ 'X-Client-ID': 12345, 'X-Client-Secret': 54321 });
    });

    it('eager parses JSON', function () {
      expect(args.json).to.be.true;
    });

  });

  context('a valid response', function () {
    let promiseResponse;

    beforeEach(function () {
      http.mock_method = function () {
        return new Promise(function (res) {
          res({
            name: 'NameTest',
            phone_numbers: [{ number: '888-888 - 8888', type: 'Toll-Free' }]
          });
        })
      };
      promiseResponse = apiService(config, http, URL, _)('mock_method', {});
    });

    it('resolves with the response', function () {
      return expect(promiseResponse).to.eventually.eql({
        name: 'NameTest',
        phone_numbers: [{ number: '888-888 - 8888', type: 'Toll-Free' }]
      });
    });
  });

  context('a rejected request (failure)', function () {
    let promiseResponse;

    beforeEach(function () {
      http.mock_method = function () {
        return new Promise(function (res, rej) { rej(new Error('oh noes')); });
      };
      promiseResponse = apiService(config, http, URL, _)('mock_method', {});
    });

    it('rejects with a validation error', function () {
      return expect(promiseResponse).to.be.rejectedWith(Error, 'oh noes')
    });
  });

  context('#get', function () {
    let args;

    beforeEach(function () {
      sinon.spy(http, 'get');
      apiService(config, http, URL, _).get({ route: '/some/path', qs: { postal_code: '55555' } });
      args = http.get.getCall(0).args[0];
    });

    it('makes a get request', function () {
      expect(http.get).to.have.been.called;
    });

    it('adds the route correctly', function () {
      expect(args.url).to.eql('http://api.test.com/some/path');
    });

    it('adds the qs correctly', function () {
      expect(args.qs).to.eql({ postal_code: '55555' })
    });
  });
});