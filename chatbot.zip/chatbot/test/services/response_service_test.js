'use strict';

require('../');

const expect = require('chai').expect;
const Promise = require('bluebird');
const request = require('request-promise');
const responseService = require('../../app/services/response_service');
const constants = require('../../config').voiceOnlyData;

describe('responseService', function () {
  let service, req, response, randomHelper;

  describe('.build', function () {
    beforeEach(function () {
      req = {
        body: {
          result: {
            action: '',
            resolvedQuery: '',
            contexts: [],
            actionIncomplete: false,
            fulfillment: {
              speech: '',
              messages: [ {type: 0, speech: ''} ]
            }
          },
          originalRequest: {
            data: {
              sender: {
                id: null
              }
            },
            souce: ''
          }
        }
      };
      randomHelper = {
        random: function () {
          return .04;
        }
      };
      service = responseService(Promise, request, constants, randomHelper);
    });

      context('shared', function () {
        it('should initialize its functions', function () {
          expect(responseService({}, {}, {}).build).isFunction;
        });
      });

      context('when the request does not come from a voice device', function () {
        it('does not contain any google specific attributes of simple responses, suggestion chips, and reprompts', function (done) {
          response = 'Penguins are your friends.';
          return service.build(req, response).then(function (message) {
            expect(message).to.deep.equal({
              speech: 'Penguins are your friends.',
              displayText: 'Penguins are your friends.',
              contextOut: [],
              source: 'LegalShield-api',
              messages: [
                {
                  type: 0,
                  speech: 'Penguins are your friends.'
                },
                {
                  type: 2,
                  replies: ['Join Our Community', 'Tip of the Day', 'Meet Our Law Firms']
                }
              ]
            });
            done();
          });
        });

        context('when the messages array contains suggestion chips', function () {
          beforeEach(function () {
            req.body.result.fulfillment.messages.push({
              type: 'suggestion_chips',
              platform: 'google',
              suggestions: [
                {
                  title: 'Gorilla'
                },
                {
                  title: 'Bear'
                }
              ]
            });
          });

          it('does not return the default quick reply data from the configs in the response', function (done) {
            response = 'Who would win?';
            return service.build(req, response).then(function (message) {
              expect(message).to.deep.equal({
                speech: 'Who would win?',
                displayText: 'Who would win?',
                contextOut: [],
                source: 'LegalShield-api',
                messages: [
                  {
                    type: 0,
                    speech: 'Who would win?'
                  },
                  {
                    type: 'suggestion_chips',
                    platform: 'google',
                    suggestions: [
                      {
                        title: 'Gorilla'
                      },
                      {
                        title: 'Bear'
                      }
                    ]
                  },
                  {
                    type: 2,
                    replies: ['Gorilla', 'Bear']
                  }
                ]
              });
              done();
            });
          });
        });
      });

      context('when the request comes from a voice device', function () {
        beforeEach(function () {
          req.body.originalRequest.source = 'google';
        });

        it('contains google specific attributes of simple responses, suggestion chips, and reprompts', function (done) {
          response = 'Penguins are your friends.';
          return service.build(req, response).then(function (message) {
            expect(message).to.deep.equal({
              speech: 'Penguins are your friends. Can I assist you with anything else today?',
              displayText: 'Penguins are your friends.',
              contextOut: [],
              source: 'LegalShield-api',
              messages: [
                {
                  type: 0,
                  speech: 'Penguins are your friends.'
                },
                {
                  type: 'simple_response',
                  platform: 'google',
                  textToSpeech: 'Penguins are your friends. Can I assist you with anything else today?',
                  displayText: 'Penguins are your friends. Can I assist you with anything else today?'
                },
                {
                  type: 'suggestion_chips',
                  platform: 'google',
                  suggestions: [
                    {
                      title: 'Join Our Community'
                    },
                    {
                      title: 'Tip of the Day'
                    },
                    {
                      title: 'Meet Our Law Firms'
                    }
                  ]
                }
             ]
            });
            done();
          });
        });

        context('when the action is incomplete', function () {
          it('does not contain the reprompt messages', function (done) {
            req.body.result.actionIncomplete = true;
            response = 'What is your favorite color?';
            return service.build(req, response).then(function (message) {
              expect(message).to.deep.equal({
                speech: 'What is your favorite color?',
                displayText: 'What is your favorite color?',
                contextOut: [],
                source: 'LegalShield-api',
                messages: [
                  {
                    type: 0,
                    speech: 'What is your favorite color?'
                  },
                  {
                    type: 'simple_response',
                    platform: 'google',
                    textToSpeech: 'What is your favorite color?',
                    displayText: 'What is your favorite color?'
                  },
                  {
                    type: 'suggestion_chips',
                    platform: 'google',
                    suggestions: [
                      {
                        title: 'Join Our Community'
                      },
                      {
                        title: 'Tip of the Day'
                      },
                      {
                        title: 'Meet Our Law Firms'
                      }
                    ]
                  }
               ]
              });
              done();
            });
          });
        });

        context('when the contexts contain a followup', function () {
          it('does not contain the reprompt messages', function (done) {
            req.body.result.contexts = [{ name: 'color-followup', lifespan: 1 }];
            response = 'What is your favorite color?';
            return service.build(req, response).then(function (message) {
              expect(message).to.deep.equal({
                speech: 'What is your favorite color?',
                displayText: 'What is your favorite color?',
                contextOut: [],
                source: 'LegalShield-api',
                messages: [
                  {
                    type: 0,
                    speech: 'What is your favorite color?'
                  },
                  {
                    type: 'simple_response',
                    platform: 'google',
                    textToSpeech: 'What is your favorite color?',
                    displayText: 'What is your favorite color?'
                  },
                  {
                    type: 'suggestion_chips',
                    platform: 'google',
                    suggestions: [
                      {
                        title: 'Join Our Community'
                      },
                      {
                        title: 'Tip of the Day'
                      },
                      {
                        title: 'Meet Our Law Firms'
                      }
                    ]
                  }
               ]
              });
              done();
            });
          });
        });

        context('when the messages array contains a card', function () {
          it('does not return the google quick reply data in the response', function (done) {
            req.body.result.fulfillment.messages.push({ type: 'basic_card', platform: 'google', title: 'I be a card!' });
            response = 'Check out this sweet card!';
            return service.build(req, response).then(function (message) {
              expect(message).to.deep.equal({
                speech: 'Check out this sweet card! Can I assist you with anything else today?',
                displayText: 'Check out this sweet card!',
                contextOut: [],
                source: 'LegalShield-api',
                messages: [
                  {
                    type: 0,
                    speech: 'Check out this sweet card!'
                  },
                  {
                    type: 'basic_card',
                    platform: 'google',
                    title: 'I be a card!'
                  },
                  {
                    type: 'simple_response',
                    platform: 'google',
                    textToSpeech: 'Check out this sweet card! Can I assist you with anything else today?',
                    displayText: 'Check out this sweet card! Can I assist you with anything else today?'
                  }
               ]
              });
              done();
            });
          });
        });

        context('when the messages array already contains suggestion chips', function () {
          beforeEach(function () {
            req.body.result.contexts = [{ name: 'battle-followup', lifespan: 1 }];
            req.body.result.fulfillment.messages.push({
              type: 'suggestion_chips',
              platform: 'google',
              suggestions: [
                {
                  title: 'Gorilla'
                },
                {
                  title: 'Bear'
                }
              ]
            });
          });

          it('does not return the default google quick reply data from the configs in the response', function (done) {
            response = 'No seriously, who would win?';
            return service.build(req, response).then(function (message) {
              expect(message).to.deep.equal({
                speech: 'No seriously, who would win?',
                displayText: 'No seriously, who would win?',
                contextOut: [],
                source: 'LegalShield-api',
                messages: [
                  {
                    type: 0,
                    speech: 'No seriously, who would win?'
                  },
                  {
                    type: 'suggestion_chips',
                    platform: 'google',
                    suggestions: [
                      {
                        title: 'Gorilla'
                      },
                      {
                        title: 'Bear'
                      }
                    ]
                  },
                  {
                    type: 'simple_response',
                    platform: 'google',
                    textToSpeech: 'No seriously, who would win?',
                    displayText: 'No seriously, who would win?'
                  }
               ]
              });
              done();
            });
          });
        });
      });
    });
  });
