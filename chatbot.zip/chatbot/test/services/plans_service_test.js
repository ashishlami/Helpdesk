'use strict';

require('../');

const chai = require("chai");
const expect = require('chai').expect;
const sinon = require('sinon');
const sinonChai = require("sinon-chai");
const Promise = require('bluebird');
const plansService = require('../../app/services/plans_service');

chai.use(sinonChai);

describe('plansService', function () {
  let service, region, plansRepository, messages, regionHelper, req;

  beforeEach(function () {
    messages = {
      noPlansFound: 'No plans are available in this location.'
    };

    regionHelper = function (input) {
      const regions = {
        'OKLAHOMA': 'OK',
        'NEW YORK': 'NY',
        'MANITOBA': 'MB'
      };
      input = input.toUpperCase();
      if (regions[input]) {
        return regions[input];
      } else if (Object.values(regions).indexOf(input) > -1) {
        return input;
      } else {
        return;
      }
    }
  });

  describe('.execute', function () {
    beforeEach(function () {
      plansRepository = {
        findOne: function (query) {
          return new Promise(function (resolve, reject) {
            switch (query.region) {
              case 'OK': resolve([
                          {
                            name: 'Test Legal Plan<br/>(Test plan for testing)',
                            details: {
                              price: 19.99
                            },
                          },
                          {
                            name: 'Test Business Plan<br/>(Test plan for more testing)',
                            details: {
                              price: 24.99
                            }
                          }
                        ]);
                        break;
              default: reject('No plans found');
            }
        });
        }
      }
      sinon.spy(plansRepository, 'findOne');
      service = plansService(Promise, messages, plansRepository, regionHelper);
    });

    context('when the request comes from an associate source', function () {
      context('when the query has a valid region', function () {
        it('fetches the correct plans', function () {
          req = { body: { result: { parameters: { region: 'Oklahoma' } }, originalRequest: { source: 'WALS'} } };
          return service.execute(req).then(function (message) {
            expect(plansRepository.findOne).to.have.been.calledWith({ region: 'OK' });
          });
        });

        it('returns the correct plan information without any html tags', function () {
          req = { body: { result: { parameters: { region: 'Ok' } }, originalRequest: { source: 'WALS'} } };
          return service.execute(req).then(function (message) {
            expect(message).to.eql('Plans available in Ok are Test Legal Plan ($19.99), Test Business Plan ($24.99).');
          });
        });
      });

      context('when the query does not have a valid region', function () {
        it('returns the stock message', function () {
          req = { body: { result: { parameters: { region: 'Minisoda' } }, originalRequest: { source: 'WALS'} } };
          return service.execute(req).then(function (message) {
            expect(message).to.eql(messages.noPlansFound);
          });
        });
      });
    });

    context('when the request does not come from an associate source', function () {
      it('returns the default message from the request', function () {
        req = { body: { result: { parameters: { region: 'mb' }, fulfillment: { speech: 'let me google that for you.'} }, originalRequest: { source: 'legalshield'} } };
        return service.execute(req).then(function (message) {
          expect(message).to.eql('let me google that for you.');
        });
      });
    });
  });
});
