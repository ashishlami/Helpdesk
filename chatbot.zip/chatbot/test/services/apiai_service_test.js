'use strict';

require('../');

const expect = require('chai').expect;
const Promise = require('bluebird');
const apiAIService = require('../../app/services/apiai_service');
const request = require('request-promise');
const apiaiConfig = require('../../config').apiai;
const url = require('url');

describe('apiAIService', function () {
  describe('.fetchByPhrase', function () {
    let apiai, service, urlformat, requestStub, urlStub, moment;

    beforeEach(function () {
      apiai = {
        client_token: '123',
        url: 'https://test.com/v1/query'
      };

      urlStub = {
        parse: function (domain) {
          return { search: null, pathname: null, href: domain }
        },
        format: function (resourceUrl) {
          urlformat = `${resourceUrl.href}?v=20170512&query=Question?&lang=en&sessionId=123`;
          return urlformat;
        },
      };

      requestStub = {
        get: function (json) {
          return new Promise(function (resolve, reject) {
            resolve({
              result: {
                resolvedQuery: 'Question?',
                fulfillment: { speech: 'Text', displayText: 'text' }
              }
            });
          });
        }
      };

      moment = function () {
        return {
          tz: function (timeZone) {
            return { format: function () { return '20170512'; } }
          }
        }
      };

      service = apiAIService(requestStub, apiai, urlStub, moment);
    });

    context('shared', function () {
      it('should initialize its functions', function () {
        expect(service.fetchByPhrase).to.not.be.undefined;;
      });

      it('checks if url returns the correct format', function () {
        return service.fetchByPhrase('Question?', null).then(function (responses) {
          expect(urlformat).to.eql('https://test.com/v1/query?v=20170512&query=Question?&lang=en&sessionId=123');
        });
      });

      it('checks if request returns JSON with response', function () {
        return service.fetchByPhrase('Question?', null).then(function (responses) {
          expect(responses).to.eql({ speech: 'Text', displayText: 'text' });
        });
      });
    });
  });

  describe('.fetchByPhraseDemo', function () {
    let service, resolvedQuery;

    beforeEach(function () {
      service = apiAIService(request, apiaiConfig, url);
    });

    context('shared', function () {
      context('When the user asks to speak to a live agent', function () {
        context('Associate Services', function () {
          it('returns the Contact - AS Only Chat intent', function () {
            resolvedQuery = "Contact associate services";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Contact - AS Only Chat');
            });
          });
        });

        context('Member Services', function () {
          it('returns the Contact - MS Only Chat intent', function () {
            resolvedQuery = "Contact member services";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Contact - MS Only Chat');
            });
          });
        });

        context('Corporate Contact', function () {
          it('returns the Corporate - Contact intent', function () {
            resolvedQuery = "speak to a real person";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Corporate - Contact');
            });
          });
        });
      });

      context('When the user asks for provider info', function () {
        context('by State Name', function () {
          it('returns the Law Firm - Contact by State intent', function () {
            resolvedQuery = "provider for Oklahoma";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Law Firm - Contact by State');
            });
          });
        });

        context('by State Abbreviation', function () {
          it('returns the Law Firm - Contact by StateAbbrev Intent', function () {
            resolvedQuery = "what's the provider firm for TX";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Law Firm - Contact by StateAbbrev');
            });
          });
        });

        context('by Zip Code', function () {
          it('returns the Law Firm - Contact by Zip intent', function () {
            resolvedQuery = "find my provider";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Law Firm - Contact by Zip');
            });
          });
        });

        context('In Florida', function () {
          it('returns the Law Firm - Contact by Zip intent', function () {
            resolvedQuery = "who is the provider in Florida";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Law Firm - Contact by Zip');
            });
          });
        });
      });

      context('General LegalShield information', function () {
        context('When the user asks what is LegalShield', function () {
          it('returns the LegalShield - About intent', function () {
            resolvedQuery = "what is legalshield";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('LegalShield - About');
            });
          });
        });

        context('When the user asks about Plans and Pricing', function () {
          it('returns the Plans - Cost intent', function () {
            resolvedQuery = "how much does legalshield cost";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Plans - Cost');
            });
          });
        });

        context('When the user asks about Forms by LegalShield', function () {
          it('returns the Products - Forms intent', function () {
            resolvedQuery = "what is forms by LegalShield";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Products - Forms');
            });
          });
        });

        context('When the user asks how to become an associate', function () {
          it('returns the AOBO - Becoming an Associate intent', function () {
            resolvedQuery = "I want to become an associate";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('AOBO - Becoming an Associate');
            });
          });
        });

        context('When the user asks if LegalShield has a mobile app', function () {
          it('returns the Info - LS Mobile Apps intent', function () {
            resolvedQuery = "is there a mobile app";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Info - LS Mobile Apps');
            });
          });
        });
      });

      context('LegalShield Coverage', function () {
        context('When the user asks if LegalShield offers will services', function () {
          it('returns the Will - Get my Will intent', function () {
            resolvedQuery = "Does the LegalShield membership cover getting my will done";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Will - Get my Will');
            });
          });
        });

        context('When the user asks if civil lawsuits are covered', function () {
          it('returns the Ttwenty AOL - Civil Litigation intent', function () {
            resolvedQuery = "does legalshield cover civil lawsuit";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Ttwenty AOL - Civil Litigation');
            });
          });
        });

        context('When the user asks if LS helps with divorce', function () {
          it('returns the Ttwenty AOL - Divorce intent', function () {
            resolvedQuery = "Can you help me with divorce";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Ttwenty AOL - Divorce');
            });
          });
        });

        context('When the user asks about moving violations', function () {
          it('returns the Ttwenty AOL - Traffic intent', function () {
            resolvedQuery = "do you cover tickets";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Ttwenty AOL - Traffic');
            });
          });
        });

        context('When the user asks about coverage for their family', function () {
          it('returns the Plans - Family intent', function () {
            resolvedQuery = "what is the age limit for a child on their parents plan";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Plans - Family');
            });
          });
        });

        context('When the user asks about starting a small business', function () {
          it('returns the Info - Launch intent', function () {
            resolvedQuery = "Can you help my start a business";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Info - Launch');
            });
          });
        });
      });

      context('Membership specific questions', function () {
        context('When the user asks how to create a Members Only login', function () {
          it('returns the Login - Create an Account intent', function () {
            resolvedQuery = "when can i create a members only account";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Login - Create an Account');
            });
          });
        });

        context('When the user asks how to find their member number', function () {
          it('returns the Info - Membership Number intent', function () {
            resolvedQuery = "what is my member number";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Info - Membership Number');
            });
          });
        });

        context('When the user asks how to update their billing info', function () {
          it('returns the Info - Billing intent', function () {
            resolvedQuery = "how can I update my credit card";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Info - Billing');
            });
          });
        });

        context('When the user asks how to reset their password', function () {
          it('returns the Website - Password Reset intent', function () {
            resolvedQuery = "I forgot my password";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Website - Password Reset');
            });
          });
        });

        context('When the user asks how to update their contact information', function () {
          it('returns the Member - Contact Info intent', function () {
            resolvedQuery = "how do I update my contact information";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Member - Contact Info');
            });
          });
        });

        context('When the user asks how to report a negative experience with their provider', function () {
          it('returns the Concern - Negative Experience intent', function () {
            resolvedQuery = "how do i file an attorney concern";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Concern - Negative Experience');
            });
          });
        });

        context('When the user asks about cancelling thier membership', function () {
          it('returns the Member - Cancelling intent', function () {
            resolvedQuery = "I want to cancel";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Member - Cancelling');
            });
          });
        });
      });

      context('Associateship specific questions', function () {
        context('When the user asks how to find their Hubsite', function () {
          it('returns the AOBO - Hubsites intent', function () {
            resolvedQuery = "What is my website";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('Marketing Site');
            });
          });
        });

        context('When the user asks about compensation', function () {
          it('returns the AOBO - Compensation intent', function () {
            resolvedQuery = "Where can I find the compensation plans in the AOBO";
            return service.fetchByPhraseDemo(resolvedQuery).then(function (message) {
              expect(message).to.equal('AOBO - Compensation');
            });
          });
        });
      });
    });
  });
});
