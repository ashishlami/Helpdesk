'use strict';

require('../');

const expect = require('chai').expect;
const chatbaseService = require('../../app/services/chatbase_service');
const url = require('url');
const request = require('request-promise');
const chatbaseConfig = require('../../config').chatbase;

describe('chatbaseService', function () {
  let service, req, reqFallback;

  describe('.sendAnalytics', function () {
    beforeEach(function () {
      req = {
        body: {
          sessionId: new Date().getTime(),
          originalRequest: {
            source: 'test'
          },
          result: {
            source: 'test',
            resolvedQuery: 'Where do test?',
            metadata: {
              intentName: 'Test Intent'
            },
            fulfillment: {
              speech: 'test the stuff'
            }
          }
        }
      };
    });

    context('successfully sends the interaction to chatbase analytics service', function () {
      beforeEach(function () {
        service = chatbaseService(request, chatbaseConfig, url);
      });
      it('returns a success status', function () {
        return service.sendAnalytics(req).then(function (response) {
          expect(response.status).to.equal(200);
        });
      });
    });

    context('sets the source based on the original request source attribute', function () {
      beforeEach(function () {
        service = {
          sendAnalytics: function (req) {
            return new Promise(function (resolve, reject) {
              let source = ((req.body || {}).originalRequest || {}).source;
              let platform = source || 'Web';
              resolve(platform);
            });
          }
        };
      });

      it('returns the source when one is passed in', function () {
        req.body.originalRequest.source = 'googleTest';
        return service.sendAnalytics(req).then(function (response) {
          expect(response).to.equal('googleTest');
        });
      });

      it('returns the default Web as the source when one is not defined', function () {
        req.body.originalRequest.source = '';
        return service.sendAnalytics(req).then(function (response) {
          expect(response).to.equal('Web');
        });
      })
    });
  });
});
