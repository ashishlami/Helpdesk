'use strict';

require('../');

const expect = require('chai').expect;
const sinon = require('sinon');
const agentsController = require('../../app/controllers/agents_controller');
const Promise = require('bluebird');
const _ = require('lodash');

describe('agentsController', function () {
  describe('.create', function () {
    let controller, apiAIService, req, res;

    beforeEach(function () {
      apiAIService = {
        fetchByPhrase: function (resolvedQuery) { return new Promise(function (resolve) { resolve({ result: { resolvedQuery: 'Question?', fulfillment: { speech: 'speech', displayText: 'text', messages: 'messages' } } }); }) }
      };
      req = { body: { result: { resolvedQuery: 'Question?' } } };
      res = { json: function (args) { } };
      controller = agentsController(apiAIService, _);

      sinon.spy(apiAIService, 'fetchByPhrase');
      controller.create(req, res, function (err) { });
    });

    context('shared', function () {
      it('should initialize its functions', function () {
        expect(controller.create).to.not.be.undefined;;;
      });
    });

    context('setup', function () {
      it('makes a request to apiAIService', function () {
        expect(apiAIService.fetchByPhrase).to.have.been.called;
      });
    });

    context('success', function () {
      beforeEach(function () {
        apiAIService = {
          fetchByPhrase: function (resolvedQuery) { return new Promise(function (resolve) { resolve({ speech: 'speech', displayText: 'text', messages: 'messages' }); }) }
        };

        req = { body: { result: { resolvedQuery: 'Question?' } } };

        controller = agentsController(apiAIService, _);
      });

      it('returns response', function (done) {
        res.json = function (args) {
          expect(args).to.eql({
            speech: 'speech',
            displayText: 'speech',
            messages: 'messages',
            data: {},
            contextOut: [],
            source: 'LegalShield-api'
          });
          done();
        }

        controller.create(req, res, function (err) { });
      });
    });

    context('failure', function () {
      beforeEach(function () {
        apiAIService = {
          fetchByPhrase: function (resolvedQuery) { return new Promise(function (resolve, reject) { reject(new Error('ERROR')); }) }
        };

        req = { body: { result: { resolvedQuery: 'Question?' } } };

        controller = agentsController(apiAIService, _);
      });

      it('recieves an error', function (done) {
        res.json = function (args) {
          expect(args).to.eql({ speech: 'ERROR', displayText: 'ERROR', data: {}, contextOut: [], source: 'LegalShield-api' });
          done();
        }

        controller.create(req, res, function (err) { });
      });
    });
  });
});
