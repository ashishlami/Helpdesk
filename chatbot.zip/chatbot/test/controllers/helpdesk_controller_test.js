'use strict';

require('../');

const expect = require('chai').expect;
const sinon = require('sinon');
const helpdeskController = require('../../app/controllers/helpdesk_controller');
const Promise = require('bluebird');

describe('helpdeskController', function () {
  describe('.create', function () {
    let controller, cherwellService, req, res;

    beforeEach(function () {
      cherwellService = {
        getToken: function (req) {
          return new Promise(function (resolve) {
             resolve({ access_token: '', status: 200 });
           })
         }
       };

       req = { body: { result: { resolvedQuery: 'Question?', action: 'action', fulfillment: { speech: 'welcome', messages: [{ type: 0, speech: 'welcome' }] } } } };
       res = { sendStatus : function (args) { } };
       controller = helpdeskController(cherwellService);

       sinon.spy(cherwellService, 'getToken');
     });

    context('shared', function () {
      it('should initialize its functions', function () {
        expect(controller.create).to.not.be.undefined;
      });
   });

    context('setup', function () {
      beforeEach(function () {
        req = {body: {result: {resolvedQuery: '', action: 'create.incident', fulfillment: {speech: ''}}}};
        controller.create(req, res, function (err) {
        });

        it('makes a call to cherwellService.getToken', function () {
          expect(cherwellService.getToken).to.have.been.called;
        });
      });
    });

    context('success', function () {
      context('when the action is create.incident', function () {
        beforeEach(function () {
          req = { body: { result: { action: '', fulfillment: { speech: '', messages: [{ type: 0, speech: '' }] } } } };
        });

        it('returns a success status', function () {
          return cherwellService.getToken().then(function (message) {
            expect(message.status).to.equal(200);
          });
        });
      });
    });
  });
});
