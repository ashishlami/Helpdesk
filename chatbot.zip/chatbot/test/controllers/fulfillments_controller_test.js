'use strict';

require('../');

const expect = require('chai').expect;
const sinon = require('sinon');
const fulfillmentsController = require('../../app/controllers/fulfillments_controller');
const Promise = require('bluebird');
const constants = require('../../config').messages;
const voiceConstants = require('../../config').voiceOnlyData;
const responseService = require('../../app/services/response_service');
const request = require('request-promise');

describe('fulfillmentsController', function () {
  describe('.create', function () {
    let controller, messageService, providerService, plansService, chatbaseService, randomHelper, req, res, resService, contactService;

    beforeEach(function () {
      contactService = {
        execute: function (req) {
          return new Promise(function (resolve) {
            resolve(constants.officeClosed + constants.memberServicesEmail);
          })
        }
      };
      messageService = {
        execute: function (req) {
          return new Promise(function (resolve) {
            let speech = (((req.body || {}).result || {}).fulfillment || {}).speech;
            speech ? resolve(speech) : resolve(constants.defaultMessage);
          })
        }
      };
      providerService = {
        execute: function (req) {
          return new Promise(function (resolve) {
            resolve(constants.noProviderFound);
          })
        }
      };
      plansService = {
        execute: function (req) {
          return new Promise(function (resolve) {
            resolve(constants.noPlansFound);
          })
        }
      };
      chatbaseService = {
        sendAnalytics: function (req) {
          return new Promise(function (resolve) {
            resolve({ message_id: '1010101010', status: 200 });
          })
        }
      };
      randomHelper = {
        random: function () {
          return .04;
        }
      };
      resService = responseService(Promise, request, voiceConstants, randomHelper);
      req = { body: { result: { resolvedQuery: 'Question?', action: 'action', fulfillment: { speech: 'welcome', messages: [{ type: 0, speech: 'welcome' }] } } } };
      res = { json: function (args) { } };
      controller = fulfillmentsController(messageService, providerService, plansService, chatbaseService, resService, contactService);

      sinon.spy(contactService, 'execute');
      sinon.spy(messageService, 'execute');
      sinon.spy(providerService, 'execute');
      sinon.spy(plansService, 'execute');
    });

    context('shared', function () {
      beforeEach(function () {
        controller.create(req, res, function (err) { });
      });
      it('should initialize its functions', function () {
        expect(controller.create).to.not.be.undefined;
      });
    });

    context('setup', function () {
      context('when the action is get.contact', function () {
        beforeEach(function () {
          req = { body: { result: { resolvedQuery: 'Question?', action: 'get.contact', fulfillment: { speech: 'speech' } } } };
          controller.create(req, res, function (err) { });
        });

        it('makes a call to contactService.execute', function () {
          expect(contactService.execute).to.have.been.called;
        });
      });

      context('when the action is get.provider', function () {
        beforeEach(function () {
          req = { body: { result: { parameter: '74820', action: 'get.provider', fulfillment: { speech: '' } } } };
          controller.create(req, res, function (err) { });
        });

        it('makes a call to providerService.execute', function () {
          expect(providerService.execute).to.have.been.called;
        });
      });

      context('when the action is get.plans', function () {
        beforeEach(function () {
          req = { body: { result: { parameter: 'Oklahoma', action: 'get.plans', fulfillment: { speech: '' } } } };
          controller.create(req, res, function (err) { });
        });

        it('makes a call to plansService.execute', function () {
          expect(plansService.execute).to.have.been.called;
        });
      });

      context('when the action is undefined', function () {
        beforeEach(function () {
          req = { body: { result: { resolvedQuery: 'Question?', action: '', fulfillment: { speech: 'speech', messages: [{ type: 0, speech: 'speech' }] } } } };
          controller.create(req, res, function (err) { });
        });

        it('makes a call to messageService.execute', function () {
          expect(messageService.execute).to.have.been.called;
        });
      });
    });

    context('success', function () {
      context('when the action is get.contact', function () {
        beforeEach(function () {
          req = { body: { result: { action: 'get.contact', fulfillment: { speech: '', messages: [{ type: 0, speech: '' }] } } } };
        });

        it('returns live chat response', function (done) {
          res.json = function (args) {
            expect(args).to.eql({
              speech: 'You can connect with us via email, Member Services at memberservices@legalshield.com.',
              displayText: 'You can connect with us via email, Member Services at memberservices@legalshield.com.',
              messages: [
                {
                  type: 0,
                  speech: 'You can connect with us via email, Member Services at memberservices@legalshield.com.'
                },
                {
                  type: 2,
                  replies: ['Join Our Community', 'Tip of the Day', 'Meet Our Law Firms']
                }
              ],
              contextOut: [],
              source: 'LegalShield-api'
            });
            done();
          }
          controller.create(req, res, function (err) { });
        });
      });

      context('when the action is get.provider', function () {
        beforeEach(function () {
          req = { body: { result: { parameter: '74820', action: 'get.provider', fulfillment: { speech: '', messages: [{ type: 0, speech: '' }] } } } };
        });

        it('returns provider info response', function (done) {
          res.json = function (args) {
            expect(args).to.eql({
              speech: 'The location you provided seems to be outside of our coverage area. Please ensure the location you provided is correct.',
              displayText: 'The location you provided seems to be outside of our coverage area. Please ensure the location you provided is correct.',
              messages: [
                {
                  type: 0,
                  speech: 'The location you provided seems to be outside of our coverage area. Please ensure the location you provided is correct.'
                },
                {
                  type: 2,
                  replies: ['Join Our Community', 'Tip of the Day', 'Meet Our Law Firms']
                }
              ],
              contextOut: [],
              source: 'LegalShield-api'
            });
            done();
          }
          controller.create(req, res, function (err) { });
        });
      });

      context('when the action is get.plans', function () {
        beforeEach(function () {
          req = { body: { result: { parameter: 'Oklahoma', action: 'get.plans', fulfillment: { speech: '', messages: [{ type: 0, speech: '' }] } } } };
        });

        it('returns plans info response', function (done) {
          res.json = function (args) {
            expect(args).to.eql({
              speech: 'No plans are available in this location.',
              displayText: 'No plans are available in this location.',
              messages: [
                {
                  type: 0,
                  speech: 'No plans are available in this location.'
                },
                {
                  type: 2,
                  replies: ['Join Our Community', 'Tip of the Day', 'Meet Our Law Firms']
                }
              ],
              contextOut: [],
              source: 'LegalShield-api'
            });
            done();
          }
          controller.create(req, res, function (err) { });
        });
      });

      context('when the action is undefined', function () {
        beforeEach(function () {
          req = { body: { result: { resolvedQuery: '', action: '', fulfillment: { speech: 'Hi', messages: [{ type: 0, speech: '' }] } } } };
        });

        it('returns speech as the response', function (done) {
          res.json = function (args) {
            expect(args).to.eql({
              speech: 'Hi',
              displayText: 'Hi',
              messages: [
                {
                  type: 0,
                  speech: 'Hi'
                },
                {
                  type: 2,
                  replies: ['Join Our Community', 'Tip of the Day', 'Meet Our Law Firms']
                }
              ],
              contextOut: [],
              source: 'LegalShield-api'
            });
            done();
          }
          controller.create(req, res, function (err) { });
        });
      });
    });

    context('failure', function () {
      beforeEach(function () {
        messageService = {
          execute: function (resolvedQuery) { return new Promise(function (resolve, reject) { reject(new Error('ERROR')); }) }
        };
        controller = fulfillmentsController(messageService, providerService, plansService, chatbaseService, resService, contactService);
      });

      it('recieves an error', function (done) {
        res.json = function (args) {
          expect(args).to.eql({
            speech: 'ERROR',
            displayText: 'ERROR',
            messages: [
              {
                type: 0,
                speech: 'ERROR'
              },
              {
                type: 2,
                replies: ['Join Our Community', 'Tip of the Day', 'Meet Our Law Firms']
              }
            ],
            contextOut: [],
            source: 'LegalShield-api'
          });
          done();
        }
        controller.create(req, res, function (err) { });
      });
    });
  });
});
