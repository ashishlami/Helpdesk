'use strict';

require('chai').use(require('chai-as-promised'));
