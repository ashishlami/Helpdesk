'use strict';

require('../');

const expect = require('chai').expect;
const sinon = require('sinon');
const URL = require('url');
const providerService = require('../../app/repositories/provider_repository');
const apiConfig = require('../../config').apiLegalshield;

context('providerService', function () {
  describe('#findOne', function () {
    let apiService, query;

    beforeEach(function () {
      query = { postal_code: '55555' };
      apiService = { get: function () { } };
    });

    context('making the correct call', function () {
      let args;

      beforeEach(function () {
        apiService.get = function () {
          return new Promise(function (res) {
            res({
              name: 'NameTest',
              phone_numbers: [{ number: '888-888 - 8888', type: 'Toll-Free' }]
            });
          });
        };
        sinon.spy(apiService, 'get');
        providerService(apiConfig, apiService).findOne(query);
        args = apiService.get.getCall(0).args[0];
      });

      it('makes a get request', function () {
        expect(apiService.get).to.have.been.called;
      });

      it('calls the fetch api clients endpoint on the api', function () {
        expect(args.route).to.eql('/v2/providers');
      });

      it('calls with the correct query', function () {
        expect(args.qs).to.eql(query);
      });
    });

    context('the response', function () {
      context('a valid response', function () {
        let promiseResponse;

        beforeEach(function () {
          apiService.get = function () {
            return new Promise(function (res) {
              res([{
                name: 'NameTest',
                phone_numbers: [{ number: '888-888 - 8888', type: 'Toll-Free' }]
              }]);
            });
          };
          promiseResponse = providerService(apiConfig, apiService).findOne(query);
        });

        it('returns a single provider that matches the query params', function () {
          return Promise.all([
            expect(promiseResponse).to.eventually.have.keys('name', 'phone_numbers'),
            expect(promiseResponse).to.eventually.have.property('name', 'NameTest'),
          ]);
        });
      });

      context('a rejected request (failure)', function () {
        let promiseResponse;

        beforeEach(function () {
          apiService.get = function () {
            return new Promise(function (res, rej) { rej(new Error('whoa')); });
          };
          promiseResponse = providerService(apiConfig, apiService).findOne(query);
        });

        it('rejects with a validation error', function () {
          return expect(promiseResponse).to.be.rejectedWith(Error, 'whoa')
        });
      });
    });
  });
});
