module.exports.random = function() {
  return Math.random();
}
