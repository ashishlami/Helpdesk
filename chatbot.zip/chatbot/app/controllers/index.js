'use strict';

const messageService = require('../services').messageService;
const providerService = require('../services').providerService;
const plansService = require('../services').plansService;
const _ = require('lodash');
const apiAIService = require('../services').apiAIService;
const chatbaseService = require('../services').chatbaseService;
const responseService = require('../services').responseService;
const contactService = require('../services').contactService;
const cherwellService = require('../services').cherwellService;

module.exports.fulfillmentsController = require('./fulfillments_controller')(messageService, providerService, plansService, chatbaseService, responseService, contactService);
module.exports.agentsController = require('./agents_controller')(apiAIService, _);
module.exports.helpdeskController = require('./helpdesk_controller')(cherwellService);

cherwellService.getToken().then(function (response) {
    process.env.CHERWELL_TOKEN = JSON.parse(response).access_token;
});
