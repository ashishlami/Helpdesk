'use strict';

module.exports = function (apiAIService, _) {
  let self = {};

  self.create = function (req, res, next) {
    let resolvedQuery = ((req.body || {}).result || {}).resolvedQuery;
    let agentName = (req.headers || {}).agentname;

    let resMessage = {
      data: {},
      contextOut: [],
      source: 'LegalShield-api'
    };

    apiAIService.fetchByPhrase(resolvedQuery, agentName).then(function (fulfillment) {
      res.json(_.extend({
        speech: fulfillment.speech,
        displayText: fulfillment.speech,
        messages: fulfillment.messages
      }, resMessage));
    }).catch(function (err) {
      res.json(_.extend({
        speech: err.message,
        displayText: err.message
      }, resMessage));
    });
  };

  return self;
};
