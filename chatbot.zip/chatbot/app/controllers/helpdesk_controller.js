'use strict';

var request = require("request");

module.exports = function (cherwellService) {

    let self = {};

    self.create = function (req, res, next) {
        let body = JSON.parse(req.body.payload);
        res.send('');
        cherwellService.createIncident(body)
            .then(function(response){
                request.post({url:body.response_url, body:{"response_type": "in_channel",text:response},json:true, headers:{'Content-Type': 'application/json'}})
                    .then((result) => {
                        console.log(result);
                    }).catch((err) => {
                    return err;
                });
            })
            .catch(function(err){
            });
    };

    self.popDialog=function (req, res, next) {
        cherwellService.generateForm(req)
            .then(function (response) {
                res.send('');
            })
            .catch(function (err) {
                res.json("Please contact system administrator");
            })
    };

    return self;
};
