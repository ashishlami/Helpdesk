'use strict';


module.exports = function (messageService, providerService, plansService, chatbaseService, responseService, contactService) {
  let services = {};

   services['get.provider'] = providerService;
   services['get.contact'] = contactService;
   services['get.plans'] = plansService;
   services['default'] = messageService;

  let self = {};

  self.create = function (req, res, next) {
    let action = ((req.body || {}).result || {}).action;
    if (!(action in services)) {
      action = 'default';
    }

    chatbaseService.sendAnalytics(req);

    services[action].execute(req)
      .then(function (response) {
        responseService.build(req, response).then(function (json) {
          res.json(json);
        }).catch(next);
      }).catch(function (err) {
        responseService.build(req, err.message).then(function (json) {
          res.json(json);
        }).catch(next);
      });
  };

  return self;
};
