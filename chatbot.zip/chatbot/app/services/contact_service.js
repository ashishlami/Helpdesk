'use strict';

module.exports = function (Promise, constants, voiceConstants, moment_tz, moment, facebookService, url) {
  let self = {};

  self.execute = function (req) {
    return new Promise(function (resolve, reject) {
      let resolvedQuery = ((req.body || {}).result || {}).resolvedQuery;
      let dataSenderID = ((((req.body || {}).originalRequest || {}).data || {}).sender || {}).id;
      let contexts = ((req.body || {}).result || {}).contexts;
      let source = ((req.body || {}).originalRequest || {}).source;
      const dayOfWeek = moment().format('dddd');
      const hourOfDay = moment_tz().tz('America/Chicago').format('H');
      let linkType, messageType, linkAddOn = '', stockMessage = '';
      let context = contextSetter(contexts);

      if (source === voiceConstants.GOOGLE_SOURCE || source === voiceConstants.ALEXA_SOURCE) {
        stockMessage += constants.officeClosed;
        linkType = 'Email';
        stockMessage += contextChecker(context, linkType, linkAddOn);
        resolve(stockMessage);
      }

      if ( (hourOfDay >= 7 && hourOfDay < 19) && (dayOfWeek !== 'Saturday' && dayOfWeek !== 'Sunday') ) {
        linkType = 'Link';
        stockMessage += constants.officeOpen;

        linkBuilder(dataSenderID, resolvedQuery).then(function (response) {
          linkAddOn = response;
          stockMessage += contextChecker(context, linkType, linkAddOn);
          resolve(stockMessage);
        });
      } else {
        linkType = 'Email';
        stockMessage += constants.officeClosed;
        stockMessage += contextChecker(context, linkType, linkAddOn);
        resolve(stockMessage);
      }
    });
  }

  const contextSetter = function (contexts) {
    let contextType = '';
    contexts.forEach(function(context){
      if (context.name === 'associate') {
        if (context.lifespan > 0) {
          contextType = 'associate';
        }
      } else if (context.name === 'member') {
        if (context.lifespan > 0) {
          contextType = 'member';
        }
      }
    });
    return contextType;
  };

  const linkBuilder = function (dataSenderID, resolvedQuery) {
    return new Promise(function (resolve, reject) {
      if (dataSenderID) {
        facebookService.facebookGraph(dataSenderID).then(function (responses) {
          if (responses.statusCode === 400) {
            resolve(messageLink('Facebook', resolvedQuery));
          } else {
            resolve(`&p1=&p2=${url.format(responses.first_name)}%20${url.format(responses.last_name)}&p3=Facebook&p4=${url.format(resolvedQuery)}.`);
          }
        }).catch(function (error) {
          resolve(messageLink('Facebook', resolvedQuery));
        });
      } else {
        resolve(messageLink('Website', resolvedQuery));
      }
    });
  };

  const messageLink = function (source, query) {
    return `&p1=&p2=&p3=${source}&p4=${url.format(query)}.`;
  };

  const contextChecker = function (context, linkType, linkAddOn) {
    let messageType, message;

    if (context) {
      messageType = `${context}Services${linkType}`;
      return messageBuilder(messageType, linkAddOn);
    } else {
      return combinedMessage(linkType, linkAddOn);
    }
    return message;
  };

  const combinedMessage = function (linkType, linkAddOn) {
    let message, messageType;

    messageType = `memberServices${linkType}`;
    message = messageBuilder(messageType, linkAddOn);
    message += ' Or ';
    messageType = `associateServices${linkType}`;
    message += messageBuilder(messageType, linkAddOn);
    return message;
  };

  const messageBuilder = function (messageType, linkAddOn) {
    return constants[`${messageType}`] ? constants[`${messageType}`].concat(linkAddOn) : '';
  };

  return self;
}
