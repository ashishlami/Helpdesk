'use strict';

let url=require('url');
let querystring=require('querystring');

module.exports = function (constants, request) {
    let self = {};

    self.getToken = function() {
        let resourceUrl = url.parse(constants.url);
        let body = {
            grant_type: 'password',
            client_id: constants.client_id,
            username: constants.username,
            password: constants.password
        };

        let formData = querystring.stringify(body);

        return request.post({
            url: url.format(resourceUrl),
            body: formData
        })
            .then(function (response) {
                return response;
            })
            .catch(function(err){
                return err;
            });
    };

    self.createIncident = function (payload) {
        //console.log(payload);
        let resourceUrl = "https://legalshieldtest.cherwellondemand.com/CherwellAPI/api/V1/savebusinessobject";
        return request.get("https://slack.com/api/users.profile.get?token="+ process.env.SLACK_ACCESS_TOKEN +"&user="+payload.user.id)
            .then(function(res){
                let body = {
                    "busObId": "6dd53665c0c24cab86870a21cf6434ae",
                    "fields": [
                        {
                            "dirty": true,
                            "displayName": "Description",
                            "fieldId": "252b836fc72c4149915053ca1131d138",
                            "name": "Description",
                            "value": payload.submission.longdescription
                        },
                        {
                            "dirty": true,
                            "displayName": "Priority",
                            "fieldId": "83c36313e97b4e6b9028aff3b401b71c",
                            "html": null,
                            "name": "Priority",
                            "value": "Low"
                        },
                        {
                            "dirty": true,
                            "displayName": "Owned By",
                            "fieldId": "9339fc404e4c93350bf5be446fb13d693b0bb7f219",
                            "html": null,
                            "name": "OwnedBy",
                            "value": ""
                        },
                        {
                            "dirty": true,
                            "displayName": "Customer ID",
                            "fieldId": "933bd530833c64efbf66f84114acabb3e90c6d7b8f",
                            "html": null,
                            "name": "CustomerRecID",
                            "value": "cherwell"
                        },
                        {
                            "dirty": true,
                            "displayName": "Call Source",
                            "fieldId": "93670bdf8abe2cd1f92b1f490a90c7b7d684222e13",
                            "html": null,
                            "name": "Source",
                            "value": "Slack"
                        },
                        {
                            "dirty": true,
                            "displayName": "PendingReason",
                            "fieldId": "9378aba490aadc483cf364416783a48d7d63ae11aa",
                            "html": null,
                            "name": "PendingReason",
                            "value": ""
                        },
                        {
                            "dirty": true,
                            "displayName": "Review By Deadline",
                            "fieldId": "9378aba4eb664c75b19162486199a67ac141aa8dad",
                            "html": null,
                            "name": "ReviewByDeadline",
                            "value": ""
                        },
                        {
                            "dirty": true,
                            "displayName": "Has No Open Tasks",
                            "fieldId": "93d8e75db276ba562f05794dc380c30904c3089075",
                            "html": null,
                            "name": "HasNoOpenTasks",
                            "value": "True"
                        },
                        {
                            "dirty": true,
                            "displayName": "Short Description",
                            "fieldId": "93e8ea93ff67fd95118255419690a50ef2d56f910c",
                            "html": null,
                            "name": "ShortDescription",
                            "value": payload.submission.shortdescription
                        },
                        {
                            "dirty": true,
                            "displayName": "Service",
                            "fieldId": "936725cd10c735d1dd8c5b4cd4969cb0bd833655f4",
                            "html": null,
                            "name": "Service",
                            "value": payload.submission.category.split(":")[0]
                        },
                        {
                            "dirty": true,
                            "displayName": "Category",
                            "fieldId": "9e0b434034e94781ab29598150f388aa",
                            "html": null,
                            "name": "Category",
                            "value": payload.submission.category.split(":")[1]
                        },
                        {
                            "dirty": true,
                            "displayName": "Subcategory",
                            "fieldId": "1163fda7e6a44f40bb94d2b47cc58f46",
                            "html": null,
                            "name": "Subcategory",
                            "value": "Submit Incident"
                        },
                        {
                            "dirty": true,
                            "displayName": "SlackEmailAddress",
                            "fieldId": "943c72b42afce350e1049647e8836b70b83f4b488a",
                            "html": null,
                            "name": "SlackEmailAddress",
                            "value": JSON.parse(res).profile.email
                        }
                        // {
                        //     "dirty": true,
                        //     "displayName": "Customer Display Name",
                        //     "fieldId": "93734aaff77b19d1fcfd1d4b4aba1b0af895f25788",
                        //     "html": null,
                        //     "name": "CustomerDisplayName",
                        //     "value": "Divyank Shukla"
                        // }
                    ],
                    "persist": true
                };
                return request.post({
                    url: url.format(resourceUrl),
                    body: body,
                    headers:{"Authorization":"Bearer "+process.env.CHERWELL_TOKEN},
                    json: true
                })
                    .then(function (response) {
                        let message='We have created incident number '+response.busObPublicId+' for you. Please retain this incident ID for future references.';
                        return message;
                    })
                    .catch(function(err){
                        return err;
                    });
            })
            .catch(err=>console.log(err));

    };

    self.generateForm = function(req){
        const { token, text, trigger_id } = req.body;
        if (token === process.env.SLACK_VERIFICATION_TOKEN) {
            const dialog = {
                token: process.env.SLACK_ACCESS_TOKEN,
                trigger_id,
                dialog: JSON.stringify({
                    title: 'Submit a helpdesk ticket',
                    callback_id: 'submit-ticket',
                    submit_label: 'Submit',
                    elements: [
                        {
                            label: 'Short Description',
                            type: 'text',
                            name: 'shortdescription',
                            value: text,
                            hint: '30 second summary of the problem',
                        },
                        {
                            label: 'Long Description',
                            type: 'textarea',
                            name: 'longdescription',
                            hint: 'Enter detailed description of problem'
                        },
                        {
                            label: 'Incident Category',
                            type: 'select',
                            name: 'category',
                            option_groups: [
                                {
                                    "label": "Cherwell",
                                    "options": [
                                        {
                                            "label": "Incident Ticket",
                                            "value": "Cherwell:Incident Ticket"
                                        }
                                    ]
                                },
                                {
                                    "label": "Connectivity",
                                    "options": [
                                        {
                                            "label": "Guest Account",
                                            "value": "Connectivity:Guest Account"
                                        },
                                        {
                                            "label": "Hardware Failure",
                                            "value": "Connectivity:Hardware Failure"
                                        },
                                        {
                                            "label": "VPN Access",
                                            "value": "Connectivity:VPN Access"
                                        },
                                        {
                                            "label": "Wired",
                                            "value": "Connectivity:Wired"
                                        },
                                        {
                                            "label": "Wireless",
                                            "value": "Connectivity:Wireless"
                                        },
                                    ]
                                },
                                {
                                    "label": "Desktop Management",
                                    "options": [
                                        {
                                            "label": "Desktop",
                                            "value": "Desktop Management:Desktop"
                                        },
                                        {
                                            "label": "Hardware",
                                            "value": "Desktop Management:Hardware"
                                        },
                                        {
                                            "label": "Laptop",
                                            "value": "Desktop Management:laptop"
                                        },
                                        {
                                            "label": "OS",
                                            "value": "Desktop Management:OS"
                                        },
                                        {
                                            "label": "Other",
                                            "value": "Desktop Management:Other"
                                        },
                                        {
                                            "label": "Software",
                                            "value": "Desktop Management:Software"
                                        },
                                    ]
                                },
                                {
                                    "label": "Facilities/Building",
                                    "options": [
                                        {
                                            "label": "Building Access",
                                            "value": "Facilities/Building:Building Access"
                                        },
                                        {
                                            "label": "Building Problem",
                                            "value": "Facilities/Building:Building Problem"
                                        },
                                        {
                                            "label": "Camera System",
                                            "value": "Facilities/Building:Camera System"
                                        },
                                        {
                                            "label": "Data Room",
                                            "value": "Facilities/Building:Data Room"
                                        },
                                        {
                                            "label": "Door",
                                            "value": "Facilities/Building:Door"
                                        },
                                        {
                                            "label": "Employee Badge",
                                            "value": "Facilities/Building:Employee Badgee"
                                        },
                                        {
                                            "label": "Furniture Problem",
                                            "value": "Facilities/Building:Furniture Problem"
                                        },
                                    ]
                                },
                                {
                                    "label": "Network Services",
                                    "options": [
                                        {
                                            "label": "Hardware",
                                            "value": "Network Services:Hardware"
                                        },
                                        {
                                            "label": "Software",
                                            "value": "Network Services:Software"
                                        },
                                    ]
                                },
                                {
                                    "label": "Office 365",
                                    "options": [
                                        {
                                            "label": "Mobile Cient",
                                            "value": "Office 365:Mobile Client"
                                        },
                                        {
                                            "label": "Office Suite",
                                            "value": "Office 365:Office Suite"
                                        },
                                        {
                                            "label": "OneDrive",
                                            "value": "Office 365:OneDrive"
                                        },
                                        {
                                            "label": "Outlook",
                                            "value": "Office 365:Outlook"
                                        },
                                        {
                                            "label": "OWA",
                                            "value": "Office 365:OWA"
                                        },
                                        {
                                            "label": "SharePoint Apps",
                                            "value": "Office 365:SharePoint Apps"
                                        },
                                        {
                                            "label": "Sharepoint site",
                                            "value": "Office 365:Sharepoint site"
                                        },
                                        {
                                            "label": "Skype",
                                            "value": "Office 365:Skype"
                                        },
                                    ]
                                },
                                {
                                    "label": "Prininting/Scanning",
                                    "options": [
                                        {
                                            "label": "Network",
                                            "value": "Prininting/Scanning:Network"
                                        },
                                        {
                                            "label": "Scanner",
                                            "value": "Prininting/Scanning:Scanner"
                                        },
                                    ]
                                },
                                {
                                    "label": "Provider Support",
                                    "options": [
                                        {
                                            "label": "Portal",
                                            "value": "Provider Support:Portal"
                                        },
                                        {
                                            "label": "Provider",
                                            "value": "Provider Support:Provider"
                                        },
                                    ]
                                },
                                {
                                    "label": "Security",
                                    "options": [
                                        {
                                            "label": "Offences",
                                            "value": "Security:Offenses"
                                        },
                                        {
                                            "label": "Phishing",
                                            "value": "Security:Phishing"
                                        },
                                    ]
                                },
                                {
                                    "label": "Service Desk",
                                    "options": [
                                        {
                                            "label": "Call Resolved",
                                            "value": "Service Desk:Call Resolved"
                                        },
                                        {
                                            "label": "Call Transfer",
                                            "value": "Service Desk:Call Transfer"
                                        },
                                    ]
                                },
                                {
                                    "label": "System I",
                                    "options": [
                                        {
                                            "label": "CM Client",
                                            "value": "System I:CM Client"
                                        },
                                        {
                                            "label": "Web Service",
                                            "value": "System I:Web Service"
                                        },
                                    ]
                                },
                                {
                                    "label": "Telecom",
                                    "options": [
                                        {
                                            "label": "Circuit",
                                            "value": "Telecom:Circuit"
                                        },
                                        {
                                            "label": "Conference Call",
                                            "value": "Telecom:Conference Call"
                                        },
                                        {
                                            "label": "Conference Phone",
                                            "value": "Telecom:Conference Phone"
                                        },
                                        {
                                            "label": "Desktop Telephone",
                                            "value": "Telecom:Desktop Telephone"
                                        },
                                        {
                                            "label": "Dialer",
                                            "value": "Telecom:Dialer"
                                        },
                                        {
                                            "label": "Fax",
                                            "value": "Telecom:Fax"
                                        },
                                        {
                                            "label": "Headset/Handset",
                                            "value": "Telecom:Headset/Handset"
                                        },
                                        {
                                            "label": "InContact",
                                            "value": "Telecom:InContact"
                                        },
                                        {
                                            "label": "Mobile Device",
                                            "value": "Telecom:Mobile Device"
                                        },
                                        {
                                            "label": "Nice",
                                            "value": "Telecom:Nice"
                                        },
                                        {
                                            "label": "Voicemail",
                                            "value": "Telecom:Voicemail"
                                        },
                                    ]
                                },
                                {
                                    "label": "Website",
                                    "options": [
                                        {
                                            "label": "Email",
                                            "value": "Website:Email"
                                        },
                                        {
                                            "label": "Email Blast",
                                            "value": "Website:Email Blast"
                                        },
                                        {
                                            "label": "Mobile App",
                                            "value": "Website:Mobile App"
                                        },
                                        {
                                            "label": "Site Problem",
                                            "value": "Website:Site Problem"
                                        },
                                    ]
                                }
                            ]
                        },
                    ],
                }),
            };

            return request.post({url:'https://slack.com/api/dialog.open', body:dialog,json:true, headers:{'Authorization':'Bearer '+process.env.SLACK_ACCESS_TOKEN,'Content-Type': 'application/json'}})
                .then((result) => {
                    return 'successful';
                }).catch((err) => {
                    return err;
                });
        } else {
            return 'Verification token mismatch';
        }
    };
    return self;
};
