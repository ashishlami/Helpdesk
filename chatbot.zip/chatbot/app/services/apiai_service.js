'use strict';

module.exports = function (request, apiaiConfig, url, moment) {
  let self = {}

  self.fetchByPhrase = function (resolvedQuery, agentName) {
    let resourceUrl = url.parse(apiaiConfig.url);
    resourceUrl.query = {
      v: +moment().tz('America/Chicago').format('YYYYMMDD'),
      query: resolvedQuery,
      lang: 'en',
      contexts: agentName,
      sessionId: new Date().getTime()
    };

    return request.get({
      url: url.format(resourceUrl),
      headers: {
        'Authorization': `Bearer ${apiaiConfig.client_token}`,
        'Content-Type': 'application/json'
      },
      json: true
    })
      .then(function (response) {
        return (response.result || {}).fulfillment;
      });
  };

  self.fetchByPhraseDemo = function (resolvedQuery) {
    let resourceUrl = url.parse(apiaiConfig.urlDemo);
    resourceUrl.query = {
      q: resolvedQuery,
      sessionId: new Date().getTime()
    };

    return request.get({
      url: url.format(resourceUrl),
      headers: {
        'Content-Type': 'application/json'
      },
      json: true
    })
      .then(function (response) {
        return ((response.result || {}).metadata || {}).intentName;
      });
  };

  return self;
}
