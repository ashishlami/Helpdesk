'use strict';

module.exports = function (Promise, constants, plansRepository, regionHelper) {
  let self = {};

  self.execute = function (req) {
    return new Promise(function (resolve, reject) {
      let source = ((req.body || {}).originalRequest || {}).source;
      let speech = (((req.body || {}).result || {}).fulfillment || {}).speech;

      if (source === 'WALS') {
        let region = (((req.body || {}).result || {}).parameters || {}).region;
        let query = { region: regionHelper(region) };
        let message = constants.noPlansFound;
        if (query.region) {
          plansRepository.findOne(query).then(function (plans) {
            message = `Plans available in ${region} are`;
            plans.forEach(function (plan) {
              message += ` ${plan.name.replace(/<[^>].*/g, "")} ($${plan.details.price}),`;
            });
            resolve(message.replace(/.$/,"."));
          }).catch(function (error) {
            resolve(message);
          });
        } else {
          resolve(message);
        }
      } else {
        resolve(speech);
      }
    });
  };

 return self;
}
