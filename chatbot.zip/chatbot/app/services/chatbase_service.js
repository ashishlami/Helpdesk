'use strict';

const GOOGLE_SOURCE = 'google';

module.exports = function (request, chatbaseConfig, url) {
  let self = {};

  self.sendAnalytics = function (req) {
    let resourceUrl = url.parse(chatbaseConfig.url);
    let notHandled = (((req.body || {}).result || {}).metadata || {}).intentName === 'Default Fallback Intent' ? true : false;
    let source = ((req.body || {}).originalRequest || {}).source;
    let apiKey = source === 'test' ? chatbaseConfig.api_test_key : chatbaseConfig.api_key;
    let platform = source || 'Web';
    let messageId = '';

    return request.post({
      url: url.format(resourceUrl),
      headers: {
        'Content-Type': 'application/json'
      },
      body: {
        api_key: apiKey,
        type: 'user',
        user_id: (req.body || {}).sessionId,
        time_stamp: Date.now().toString(),
        platform: platform,
        message: ((req.body || {}).result || {}).resolvedQuery,
        intent: (((req.body || {}).result || {}).metadata || {}).intentName,
        not_handled: notHandled
      },
      json: true
    });
  };

  return self;
};
