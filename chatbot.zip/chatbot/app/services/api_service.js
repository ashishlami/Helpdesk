'use strict';

module.exports = function (config, http, URL, _) {

  const DEFAULT_OPTIONS = {
    json: true,
    headers: {
      'X-Client-ID': config.client_id,
      'X-Client-Secret': config.client_secret,
    }
  };

  let urlForRoute = function (route) {
    let url = URL.parse(config.host);
    url.pathname = route;
    return URL.format(url);
  };

  let self = function (method, options) {
    options.url = urlForRoute(options.route);
    delete options.route;
    let params = _.merge(options, DEFAULT_OPTIONS);
    return http[method](params)
      .then(function (response) {
        if (response.StatusCodeError) {
          throw new Error(response.error.message);
        } else {
          return response;
        }
      });
  };

  self.get = function (options) {
    return self('get', {
      headers: { 'Content-Type': 'application/json' },
      qs: options.qs,
      route: options.route
    });
  };

  return self;
};