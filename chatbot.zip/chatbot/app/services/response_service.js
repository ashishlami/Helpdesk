'use strict';

module.exports = function (Promise, request, constants, randomHelper) {
  let self = {};

  self.build = function (req, response) {
    let messages = (((req.body || {}).result || {}).fulfillment || {}).messages;
    let source = ((req.body || {}).originalRequest || {}).source;
    let contexts = ((req.body || {}).result || {}).contexts;
    let actionIncomplete = ((req.body || {}).result || {}).actionIncomplete;

    return new Promise(function (resolve, reject) {
      let resMessage = {
        speech: response,
        displayText: response,
        messages: messages,
        contextOut: [],
        source: 'LegalShield-api'
      };

      resMessage.messages[messages.map(function(message) { return message.type; }).indexOf(constants.TEXT)].speech = response;

      if (source === constants.GOOGLE_SOURCE || source === constants.ALEXA_SOURCE) {
        resMessage = buildVoiceReponse(resMessage);
        if (!actionIncomplete && !isDialogComplete(contexts)) {
          resMessage = addRepromptToResponse(resMessage);
        }
      } else {
        resMessage = buildQuickReplies(resMessage);
      }

      resolve(resMessage);
    });
  };

  const setSimpleResponseIndex = function (resMessage) {
    return resMessage.messages.map(function(message) { return message.type; }).indexOf(constants.SIMPLE_RESPONSE);
  };

  const isDialogComplete = function (contexts) {
    return contexts.some((context) => { return (context.name.includes('followup') && context.lifespan > 0) });
  };

  const buildVoiceReponse = function (resMessage) {
    let simpleResponseIndex = setSimpleResponseIndex(resMessage);
    if (resMessage.messages[simpleResponseIndex]) {
      if (!(resMessage.messages[simpleResponseIndex].textToSpeech)) {
        resMessage.messages[simpleResponseIndex].textToSpeech = resMessage.speech;
      }
      if (!(resMessage.messages[simpleResponseIndex].displayText)) {
        resMessage.messages[simpleResponseIndex].displayText = resMessage.messages[simpleResponseIndex].textToSpeech;
      }
    } else {
      resMessage.messages.push({ type: constants.SIMPLE_RESPONSE, platform: constants.GOOGLE_SOURCE, textToSpeech: resMessage.speech, displayText: resMessage.displayText });
    }

    if (!(resMessage.messages[resMessage.messages.map(function(message) { return message.type; }).indexOf(constants.BASIC_CARD)])) {
      if (!(resMessage.messages[resMessage.messages.map(function(message) { return message.type; }).indexOf(constants.SUGGESTION_CHIPS)])) {
        resMessage.messages.push(constants.defaultQuickReplies);
      }
    }

    return resMessage;
  };

  const addRepromptToResponse = function (resMessage) {
    let simpleResponseIndex = setSimpleResponseIndex(resMessage);
    resMessage.messages[simpleResponseIndex].textToSpeech += constants.reprompt;
    resMessage.messages[simpleResponseIndex].displayText += constants.reprompt;
    resMessage.speech += constants.reprompt;
    return resMessage;
  };

  const buildQuickReplies = function (resMessage) {
    let suggestionChipsIndex = resMessage.messages.map(function(message) { return message.type; }).indexOf(constants.SUGGESTION_CHIPS);
    if (resMessage.messages[suggestionChipsIndex]) {
      resMessage.messages.push({
        type: constants.QUICK_REPLIES,
        replies: buildQuickReplyArray(resMessage.messages[suggestionChipsIndex])
      });
    } else if (randomHelper.random() > .6) {
      resMessage = buildFeedbackLoop(resMessage);
    } else {
      resMessage.messages.push({
        type: constants.QUICK_REPLIES,
        replies: buildQuickReplyArray(constants.defaultQuickReplies)
      });
    }
    return resMessage;
  };

  const buildQuickReplyArray = function (replies) {
    let quickReplies = [];
    replies.suggestions.forEach(function(reply) {
      quickReplies.push(reply.title);
    });
    return quickReplies;
  };

  const buildFeedbackLoop = function (resMessage) {
    resMessage.messages.push(constants.feedbackLoop, constants.feedbackReplies);
    resMessage.contextOut.push({
      name: 'feedbackloop',
      lifespan: 1
    });
    return resMessage;
  };

  return self;
};
