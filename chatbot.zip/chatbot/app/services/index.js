'use strict';

const Promise = require('bluebird');
const config = require('../../config');
const moment_tz = require('moment-timezone');
const moment = require('moment');
const request = require('request-promise');
const url = require('url');
const _ = require('lodash');
const apiaiConfig = require('../../config').apiai;
const apiConfig = require('../../config').apiLegalshield;
const providerRepository = require('../repositories').providerRepository;
const plansRepository = require('../repositories').plansRepository;
const chatbaseConfig = require('../../config').chatbase;
const randomHelper = require('../helpers/randomHelper');
const regionHelper = require('../../app/helpers/stateAbbrev');

const facebookService = require('./facebook_service');
module.exports.facebookService = facebookService(request, url, config.facebookGraph);

const messageService = require('./message_service');
module.exports.messageService = messageService(Promise, config.messages);

const providerService = require('./provider_service');
module.exports.providerService = providerService(Promise, config.messages, providerRepository);

const plansService = require('./plans_service');
module.exports.plansService = plansService(Promise, config.messages, plansRepository, regionHelper);

const apiAIService = require('./apiai_service');
module.exports.apiAIService = apiAIService(request, apiaiConfig, url, moment);

const chatbaseService = require('./chatbase_service');
module.exports.chatbaseService = chatbaseService(request, chatbaseConfig, url);

const responseService = require('./response_service');
module.exports.responseService = responseService(Promise, request, config.voiceOnlyData, randomHelper);

const contactService = require('./contact_service');
module.exports.contactService = contactService(Promise, config.messages, config.voiceOnlyData, moment_tz, moment, module.exports.facebookService, url);

const cherwellService = require('./cherwell_service');
module.exports.cherwellService = cherwellService(config.apiCherwell, request);
