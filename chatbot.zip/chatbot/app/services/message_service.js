'use strict';

module.exports = function (Promise, constants) {
  let self = {};

  self.execute = function (req) {
    return new Promise(function (resolve, reject) {
      let speech = (((req.body || {}).result || {}).fulfillment || {}).speech;
      let messages = constants.defaultMessage + constants.officeClosed + constants.memberServicesEmail;

      if (speech) {
        resolve(speech);
      } else {
        resolve(messages);
      }
    });
  };

return self;
}
