'use strict';

const regionHelper = require('../../app/helpers/stateAbbrev');

module.exports = function (Promise, constants, providerRepository) {
  let self = {};

  self.execute = function (req) {
    return new Promise(function (resolve, reject) {
      let parameter = (((req.body || {}).result || {}).parameters || {}).zip;
      let region = (((req.body || {}).result || {}).parameters || {}).region;
      let query = parameter ? { postal_code: parameter.toString().replace(/-|\s/g,'') } : { region: regionHelper(region) };
      let message = constants.noProviderFound;
      if (query.postal_code || query.region) {
        providerRepository.findOne(query).then(function (provider) {
          message = `Your provider's name is: ${provider.name}. Phone number is: ${provider.phone_numbers[0].number}.`;
          resolve(message);
        }).catch(function (error) {
          resolve(message);
        });
      } else {
        resolve(message);
      }
    });
  };

 return self;
}
