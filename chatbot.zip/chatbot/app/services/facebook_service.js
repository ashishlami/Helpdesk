'use strict';

module.exports = function (request, url, facebookGraph) {
  let self = {}

  self.facebookGraph = function (dataSenderID) {
    let resourceUrl = url.parse(facebookGraph.domain);
    resourceUrl.pathname = dataSenderID;
    resourceUrl.search = `?fields=first_name,last_name&access_token=${facebookGraph.access_token}`;
    return request({ url: url.format(resourceUrl), json: true });
  }

  return self;
}