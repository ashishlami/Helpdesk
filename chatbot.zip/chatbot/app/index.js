'use strict';

const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const raygun = require('raygun');
const config = require('../config');
const request = require("request-promise");

const fulfillmentsController = require('./controllers').fulfillmentsController;
const agentController = require('./controllers').agentsController;
const helpdeskController = require('./controllers').helpdeskController;

app.use(require('morgan')('dev'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get('/', function (req, res) {
    res.send('Hello World!');
});

app.post('/v1/fulfillments', fulfillmentsController.create);
app.post('/v1/agents', agentController.create);
app.post('/helpdesk/fulfillments', helpdeskController.create);
app.post('/commands', helpdeskController.popDialog);

let raygunClient = new raygun.Client().init(config.raygun.options);
if (config.raygun.offline) { raygunClient.offline(); }
app.use(raygunClient.expressHandler);

app.listen(config.port, () => {
    console.log('Node app is running on port %s in env %s', config.port, config.env);
});
