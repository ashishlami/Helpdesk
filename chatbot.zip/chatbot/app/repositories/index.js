'use strict';

const url = require('url');
const _ = require('lodash');
const request = require('request-promise');
const apiConfig = require('../../config').apiLegalshield;

const apiService = require('../services/api_service');
module.exports.apiService = apiService(apiConfig, request, url, _);

const providerRepository = require('./provider_repository');
module.exports.providerRepository = providerRepository(apiConfig, module.exports.apiService);

const plansRepository = require('./plans_repository');
module.exports.plansRepository = plansRepository(apiConfig, module.exports.apiService);
