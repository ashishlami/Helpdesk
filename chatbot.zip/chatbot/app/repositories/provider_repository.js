'use strict';

module.exports = function (config, apiService) {
  let self = {};

  self.findOne = function (query) {
    let options = {
      route: config.providers,
      qs: query
    };

    return apiService.get(options)
      .then(function (response) {
        return (response.error ? response.error : response[0]);
      });
  };

  return self;
}
