# chatbot

##scripts folder
These scripts are to make your life _easier_, you're welcome boo

###running the scripts
from Dialogflow select the agent you want to run the script on
Gear icon > Export and Import > Export as zip
Unzip the agent and move the /intents/ folder into the scripts directory
run from the command line

####dump intents names and the contents of the responses into a csv format
`npm run dump-replies`
to save into a .csv file
`npm run dump-replies > output.csv`

####average length of responses
`npm run response-length`

####find intents with the webhook off
`npm run without-webhook`

####turn on all the webhooks
`npm run turn-on-webhooks`
