const fs = require('fs');
const dirName = 'scripts/intents/';

let file;
fs.readdir(dirName, function (err, filenames) {
  filenames.forEach(function (filename) {
    file = fs.readFileSync(dirName + filename, 'utf-8');
    reply = JSON.parse(file);
    if (reply['responses']) {
      if (reply['responses'][0]['messages']) {
        reply['responses'][0]['messages'].forEach(function (message) {
          if (message['type'] === 0) {
            console.log([reply['name'], message['speech']].map(x => `"${x}"`)
            .join(', '))
          }
        });
      }
    }
  });
});
