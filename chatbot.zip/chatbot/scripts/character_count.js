const fs = require('fs');
const dirName = 'scripts/intents/';

let count = {
    number: 0,
    chars: 0,
    toolong: 0
  };
let reply;

fs.readdir(dirName, function(err, filenames) {
  filenames.forEach(function(filename) {
  count.number++;

  file = fs.readFileSync(dirName + filename, 'utf-8');
  reply = JSON.parse(file);
    if (reply['responses']) {
      if (reply['responses'][0]['messages'][0]['speech']) {
        count.chars += reply['responses'][0]['messages'][0]['speech'].length;
        if (reply['responses'][0]['messages'][0]['speech'].length > 140) {
          count.toolong++;
        }
      }
    }
  });
  console.log(`intents: ${count.number}`);
  console.log(`chars: ${count.chars}`);
  console.log(`avg: ${count.chars/count.number}`);
  console.log(`intents that are over 140: ${count.toolong}`);
});
