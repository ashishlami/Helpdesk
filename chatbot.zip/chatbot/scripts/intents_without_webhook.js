const fs = require('fs');
const dirName = 'scripts/intents/';

fs.readdir(dirName, function(err, filenames) {
  filenames.forEach(function(filename) {
    file = fs.readFileSync(dirName + filename, 'utf-8');
    reply = JSON.parse(file);
    if (reply['webhookUsed'] === false) {
      console.log(reply['name']);
    }
  });
});
