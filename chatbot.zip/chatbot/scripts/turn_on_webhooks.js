const fs = require('fs');
const dirName = 'scripts/intents/';

fs.readdir(dirName, function(err, filenames) {
  filenames.forEach(function(filename) {
    file = fs.readFileSync(dirName + filename, 'utf-8');
    new_contents = file.replace('"webhookUsed": false,', '"webhookUsed": true,');
    fs.writeFileSync(dirName + filename, new_contents, 'utf-8');
  });
});
