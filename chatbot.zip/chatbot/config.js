"use strict";

require('dotenv').config({ silent: true });

const url = require('url');

let env = process.env.NODE_ENV || 'local';

let defaultEnv = {
  env: env,
  port: process.env.PORT || 5000,
  messages: {
    defaultMessage: 'Sorry, I don\'t know that one, I\'m still learning. Please try rephrasing your question. If you prefer, ',
    contactMessage: 'You can connect with a live ',
    officeOpen: 'I can connect you with a live ',
    officeClosed: 'You can connect with us via email, ',
    memberServicesLink: 'Member Services agent at https://home-c4.incontact.com/inContact/ChatClient/ChatClientPatron.aspx?poc=785ac45b-4579-4198-9376-359d21b87f27&bu=4595114',
    memberServicesEmail: 'Member Services at memberservices@legalshield.com.',
    associateServicesLink: 'Associate Services agent at https://home-c4.incontact.com/inContact/ChatClient/ChatClientPatron.aspx?poc=60ce508d-19e9-4c70-bb47-1e6ee012d06a&bu=4595114',
    associateServicesEmail: 'Associate Services at associateservices@legalshield.com.',
    noProviderFound: 'The location you provided seems to be outside of our coverage area. Please ensure the location you provided is correct.',
    noPlansFound: 'No plans are available in this location.',
    lengthError: 'All queries should be less than 255 symbols.',
    lengthErrorMessage: 'I\'m sorry, your question exceeds the 255 character limit. Please try rephrasing.',
  },
  voiceOnlyData: {
    TEXT: 0,
    QUICK_REPLIES: 2,
    BASIC_CARD: 'basic_card',
    SIMPLE_RESPONSE: 'simple_response',
    SUGGESTION_CHIPS: 'suggestion_chips',
    GOOGLE_SOURCE: 'google',
    ALEXA_SOURCE: 'alexa',
    defaultQuickReplies: {
      type: 'suggestion_chips',
      platform: 'google',
      suggestions: [
         {
           title: 'Join Our Community'
         },
         {
           title: 'Tip of the Day'
         },
         {
           title: 'Meet Our Law Firms'
         }
      ]
    },
    feedbackLoop: {
      type: 0,
      speech: 'Was this helpful?'
    },
    feedbackReplies: {
        type: 2,
        replies: ['yes', 'no']
    },
    reprompt: ' Can I assist you with anything else today?'
  },
  facebookGraph: {
    domain: 'https://graph.facebook.com/v2.6/',
    access_token: 'EAALMHgZAfNLUBALSOlPonsZAgsWZCZBcOsnKI9hP6Ojclh8z3FpvavI6gufbnlxtFCn6zkVCNmNjk8FZCk5OcTuMtARLXKgsgOytB5IH5uoYQ4ZCpsPSH5ZBYKe66ZBIQwzVAool2kQCoDKykJZCU0hsKSrEMB92jsYQ4JfNAhqemPAZDZD'
  },
  apiai: {
    client_token: process.env.DIALOGFLOW_CLIENT_TOKEN,
    url: 'https://api.api.ai/v1/query',
    urlDemo: 'https://console.dialogflow.com/api-client/demo/embedded/ce078013-7956-495f-87d8-ca6cccedfbcf/demoQuery'
  },
  apiLegalshield: {
    host: process.env.API_HOST_STAGING,
    providers: process.env.API_PROVIDERS_PATH,
    plans: process.env.API_PLANS_PATH,
    client_id: process.env.LS_API_CLIENT_ID,
    client_secret: process.env.LS_API_CLIENT_SECRET
  },
  apiCherwell: {
    client_id: process.env.CHERWELL_CLIENT_ID,
    url: "https://legalshieldtest.cherwellondemand.com/CherwellAPI/token?auth_mode=Auto",
    username: process.env.CHERWELL_USERNAME,
    password: process.env.CHERWELL_PASSWORD,
    grant_type: process.env.CHERWELL_GRANT_TYPE
    },
  chatbase: {
    url: 'https://chatbase.com/api/message',
    update: '/update',
    api_key: process.env.CHATBASE_API_KEY,
    api_test_key: process.env.CHATBASE_TEST_API_KEY
  },
  raygun: {
    offline: true,
    options: {
      apiKey: '',
      offlineStorageOptions: {
        cachePath: 'raygunCache/'
      }
    }
  }
}

let config = {
  production: JSON.parse(JSON.stringify(defaultEnv)),
  staging: JSON.parse(JSON.stringify(defaultEnv)),
  local: JSON.parse(JSON.stringify(defaultEnv))
};

config.production.apiLegalshield.host = process.env.API_HOST_PROD;
config.production.raygun.offline = false;
config.production.raygun.options.api_key = process.env.RAYGUN_API_KEY;

module.exports = config[env];
